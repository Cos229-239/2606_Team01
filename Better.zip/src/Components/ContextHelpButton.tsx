import { useState } from "react";
import { useLocation } from "react-router-dom";
import { getPageHelp } from "../Data/pageHelpContent";

// ── ContextHelpButton ───────────────────────────────────────────────────
// Small (?) button that sits next to the Timer button in the toolbar.
// Looks up help content for the current route from the same data the
// full Help page reads from, and shows it in a popup without navigating
// anywhere. Renders nothing when:
//   - the current page has no counterpart section on the Help page, or
//   - the user is already on the Help page itself.
export default function ContextHelpButton() {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  const entry = getPageHelp(location.pathname);
  const onHelpPage = location.pathname.toLowerCase().replace(/\/+$/, "") === "/help";

  if (!entry || onHelpPage) {
    return null;
  }

  return (
    <>
      <button
        className="context-help-btn"
        aria-label={`Help for ${entry.title}`}
        title={`Help for ${entry.title}`}
        onClick={() => setOpen(true)}
      >
        ?
      </button>

      {open && (
        <div className="popup-overlay" onClick={() => setOpen(false)}>
          <div
            className="glass-panel context-help-popup"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="context-help-popup-header">
              <div className="help-section-header" style={{ marginBottom: 0 }}>
                <span className="help-section-icon">{entry.icon}</span>
                <div>
                  <h2 className="help-section-title">{entry.title}</h2>
                  <p className="help-section-subtitle">{entry.subtitle}</p>
                </div>
              </div>
              <button
                className="context-help-popup-close"
                aria-label="Close"
                title="Close"
                onClick={() => setOpen(false)}
              >
                ✕
              </button>
            </div>

            <div className="context-help-popup-body help-section-body">
              {entry.body}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
